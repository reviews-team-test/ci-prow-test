int main()
{
    return 0;
#ifdef A
}
#endif
