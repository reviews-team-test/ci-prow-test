#include <stdio.h>
int main()
{
    char str[10];
    snprintf(str, 10, "%s", "abc");
    return 0;
}
