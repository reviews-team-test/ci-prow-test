int a[3];

int main()
{
    a[0] = 0;
    a[1] = 0;
    a[2] = 0;
    return 0;
}
